import csv
from pprint import pprint

# csv_example = open("C:/Users/ivan.PUE/Documents/Becas_Tests/PythonEngineers/csv_example.csv").read()
# print(csv_example)

csv_example_2 = open("C:/Users/ivan.PUE/Documents/Becas_Tests/PythonEngineers/csv_example.csv")
csv_python = csv.reader(csv_example_2)
for row in csv_python:
    print("{} is in {} and has IP {}".format(row[0], row[2], row[1]))