import datetime	
right_now = datetime.datetime.now()	
four_weeks_from_now = right_now+datetime.timedelta(weeks=4)	
date_display_format = "%I:%m %p on %B %w, %Y"
print(four_weeks_from_now.strftime(date_display_format))