import requests
import json
import urllib3
from pprint import pprint
from tabulate import *

requests.packages.urllib3.disable_warnings()
url="https://devnetsbx-netacad-apicem-3.cisco.com/api/v1/host"
ticket = "ST-290-Fl5z9qbN1bg1jdF14i2n-cas"
headers={
    "content-type": "application/json",
    "X-Auth-Token": ticket
}
body_json={
    "username": "devnetuser",
    "password": "Xj3BDqbU"
}
resp = requests.get(url,headers=headers,verify=False)

print("Ticket request status:", resp.status_code)

response_json = resp.json()
pprint(response_json)