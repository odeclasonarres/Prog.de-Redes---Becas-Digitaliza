import requests
import json
import urllib3
from tabulate import *

requests.packages.urllib3.disable_warnings()
url="https://devnetsbx-netacad-apicem-3.cisco.com/api/v1/ticket"
headers={
    "content-type": "application/json"
}
body_json={
    "username": "devnetuser",
    "password": "Xj3BDqbU"
}
resp = requests.post(url,json.dumps(body_json),headers=headers,verify=False)

print("Ticket request status:", resp.status_code)

response_json = resp.json()
serviceTicket = response_json["response"]["serviceTicket"]
print("The service Ticket number is:",serviceTicket)