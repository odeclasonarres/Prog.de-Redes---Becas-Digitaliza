from pprint import pprint
import xmltodict	
xml_example=open("C:/Users/ivan.PUE/Documents/Becas_Tests/PythonEngineers/xml_example.xml").read()	
xml_dict = xmltodict.parse(xml_example)	
print(xml_dict)
print(xml_dict["interface"]["ipv4"]["address"]["ip"]) #search values as a common dict	
#we can also unparse the data with xmltodict.unparse(xml_dict)
