import yaml
from pprint import pprint
import os

print(os.getcwd())
yml_example = open("C:/Users/ivan.PUE/Documents/Becas_Tests/PythonEngineers/yaml_example.yaml").read()
pprint(yml_example)

yaml_python = yaml.load(yml_example)
pprint(yaml_python)

print(yaml_python["ietf-interfaces:interface"]["ietf-ip:ipv4"]["address"][0]["ip"])